import {ajaxPost,ajaxGet} from "./tool";
export let paramList = {
  client_ip: "",
  system: 1,
  brand: "",
  model: "",
  gid: "",
  ifa: "",
  language: "",
  ua: "",
  sdkversion: "",
  im: "",
  ma: "",
  aid: "",
  aq: "",
  os_v: "",
  app_pname: "",
  app_vn: "",
  network: "",
  pub_id: "",
  appid: "",
  unit_id: "",
  game_id: "", //测试用的
  session_id: "",
  code: "",
  ad_cat: "",
  r_num: 0,
  offset: 0,
  device_vendor: "",
  api_version: "2.1",
  tk_id: '',
  tk_ts: '',
  rxuid: '',
  req_times: '',
}
const protocol = window.location.protocol
// 指定必要参数
paramList.unit_id=1  // 图片用
paramList.appid=1 // 图片用
paramList.pub_id = '10048' // 埋点用
paramList.game_id='96' // 埋点用
export function apiGetH5RtbAdImgs(rNum, times,success){
  let url = '//stsdk.roulax.io/rtb/v1'
  let params = {
    client_ip: paramList.client_ip,
    system: paramList.system,
    os_v: paramList.os_v,
    app_pname: paramList.app_pname,
    app_vn: paramList.app_vn,
    app_vc: paramList.app_vc,
    direction: paramList.direction,
    brand: paramList.brand,
    model: paramList.model,
    adid: paramList.gid,
    idfa: paramList.idfa,
    mnc: paramList.mnc,
    mcc: paramList.mcc,
    network: paramList.network,
    language: paramList.language,
    timezone: paramList.timezone,
    ua: paramList.ua,
    sdkversion: paramList.sdkversion,
    screen_size: paramList.screen_size,
    ma: paramList.ma,
    mb: paramList.mb,
    mc: paramList.mc,
    app_bundle_name: paramList.app_bundle_name,
    device_vendor: paramList.device_vendor,
    bid_floor: paramList.bid_floor,
    appid: paramList.appid,
    unit_id: paramList.unit_id,
    r_num: rNum,
    removeads: '',
    offset: paramList.offset,
    req_https: protocol.indexOf('https') > -1 ? 1 : 0,  // 0返回http  1返回https
    req_times: paramList.req_times,
    game_id: paramList.game_id,
    game_times: times || 0,
    // h5_adid: getRxuid(),  // 20220906 直接生成
    h5_adid: 0,
  }
  let str = ''
  for(const key in params){
    str+='&'+key+'='+params[key]
  }
  str = str ?  '?'+str.substr(1): ''
  ajaxGet({
    url:url,
    params:str,
    success:success,
  })
}

/**
 * h5 新埋点
 */
export function apiH5Analytics(name, obj,success) {
  let url = protocol + '//h5-stat.roulax.io/h5_analytics'
  let message = JSON.stringify([{k: name, v: JSON.stringify(obj)}])
  let data = {
    publisher_id: paramList.pub_id,
    game_id: paramList.game_id,
    appid: paramList.appid,
    unit_id: paramList.unit_id,
    // api_type: radsdk ? 2 : 1,
    api_type: 1,
    message: message,
    // rxuid: rxuid,
    rxuid:'',
    system: paramList.system,
    os_v: paramList.os_v,
    app_pname: paramList.app_pname,
    app_vn: paramList.app_vn,
    direction: paramList.direction,
    brand: paramList.brand,
    model: paramList.model,
    adid: paramList.gid,
    idfa: '',
    mnc: paramList.mnc,
    mcc: paramList.mcc,
    network: paramList.network,
    language: paramList.language,
    timezone: paramList.timezone,
    sdkversion: paramList.sdkversion,
    screen_size: paramList.screen_size,
    ma: paramList.ma,
    mb: paramList.mb,
    mc: paramList.mc0,
    app_bundle_name: paramList.app_bundle_name,
    device_vendor: paramList.device_vendor,
    ext1: '',
    ext2: '',
    ext3: '',
    ext4: '',
    ext5: '',
    ext6: '',
    ext7: '',
    ext8: '',
    ext9: '',
    ext10: '',
  }
  ajaxPost({
    url:url,
    data:data,
    success:success,
  })
}