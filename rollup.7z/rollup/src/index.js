import {apiGetH5RtbAdImgs, apiH5Analytics} from "./api";
import {getRequestParameters} from "./tool";

(function () {
  window.addEventListener('load', init)

  function init() {
    // getAdImg()
    apiH5Analytics('ad_request', {rsession_id: 1, req_times: 2})
    test('bundle')
  }

  function test(name) {
    // 获取script链接上的参数
    let script = document.querySelectorAll('script')
    let url = ''
    for (let i = 0; i < script.length; i++) {
      if (script[i].src.indexOf(name) > -1) {
        url = script[i].src
        break
      }
    }
    console.log(url);
    let obj = getRequestParameters(url)
    console.log(obj);
    let p = document.createElement('p')
    p.innerHTML=obj.t
    document.body.appendChild(p)
  }


  function getAdImg() {
    apiGetH5RtbAdImgs(1, 1, function (res) {
      console.log('apiGetH5RtbAdImgs', res);
      res = JSON.parse(res)
      if (!res || !res.data.ad_info[0].image_list) return
      let imageObj = res.data.ad_info[0].image_list[0]
      let img = imageObj.url
      console.log('img', img);
      addImg({
        src: img,
        width: '640px'
      })
    })
  }


  /*  addImg({src: 'https://h5.roulax.io/intgame/vue/roulaxAd/img/160.gif', width: '80px', top: '70%', right: 0})
    if (isMobile()) {
      addImg({
        src: 'https://h5.roulax.io/intgame/vue/roulaxAd/img/320.gif',
        width: '95%',
        top: '100px',
        right: 0,
        isCenter: true
      })
    }*/

  function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }

  function addImg(obj) {
    let img = document.createElement('img')
    img.src = obj.src
    img.style.width = obj.width
    img.style.top = obj.top
    img.style.right = obj.right
    img.style.position = 'fixed'
    img.style.cursor = 'pointer'
    if (obj.isCenter) {
      img.style.left = '0'
      img.style.margin = '0 auto'
    }
    document.body.appendChild(img)
    img.addEventListener('click', function () {
      window.location.href = 'http://setting.roulax.io/promote?appid=83&unit_id=208&system=2&gid={gaid}'
    })
  }

})();