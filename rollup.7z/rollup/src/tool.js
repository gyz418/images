export function ajaxPost(obj) {
  let xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
      // 请求成功
      obj.success && obj.success(xmlhttp.responseText)
    }
  }
  xmlhttp.open("post", obj.url, true);
  // 设置请求头
  // 默认用字符串拼接的形式 application/x-www-form-urlencoded
  // xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  // xmlhttp.setRequestHeader('Content-Type', 'multipart/form-data')  // 表单提交  有点效果，但还是不对
  const formData = new FormData()
  for (const key in obj.data) {
    formData.append(key, obj.data[key])
  }
  xmlhttp.send(formData);
}

export function ajaxGet(obj) {
  let xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
      // 请求成功
      obj.success && obj.success(xmlhttp.responseText)
    }
  }
  xmlhttp.open('GET', obj.url + obj.params, true);
  xmlhttp.send();
}

/**
 * 获取url参数 返回一个对象
 * @returns {{}}
 */
export function getRequestParameters(url) {
  url = url || window.location.href
  const obj = {}
  const index = url.lastIndexOf('?')
  if (index === -1) return {}
  url = url.substr(index + 1)
  const arr = url.split('&')
  for (let i = 0; i < arr.length; i++) {
    const b = arr[i].indexOf('=')
    // obj[arr[i].substr(0, b).toLocaleLowerCase()] = arr[i].substr(b + 1) // 把地址栏参数名转成小写
    obj[arr[i].substr(0, b)] = arr[i].substr(b + 1)
  }
  return obj
}