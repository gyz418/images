// import resolve from '@rollup/plugin-node-resolve'
// import rollupJson from '@rollup/plugin-json'
import terser from '@rollup/plugin-terser'
import babel from '@rollup/plugin-babel'
// const production = !process.env.ROLLUP_WATCH;  // 生产环境判断
export default {
  input:'src/index.js',
  output:{
    file:'bundle.js',
    format:'iife',
    globals:{
      axios:'axios'
    }
  },
  external:['axios'],
  // plugins:[babel({babelHelpers:'bundled'}),terser({compress:{drop_console:true}})]
  plugins:[babel({babelHelpers:'bundled'})]
  // plugins:[resolve({jsnext:true,preferBuiltins:true,browser:true}),rollupJson()]
}