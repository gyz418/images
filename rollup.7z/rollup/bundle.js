(function () {
  'use strict';

  function ajaxPost(obj) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
      if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
        // 请求成功
        obj.success && obj.success(xmlhttp.responseText);
      }
    };
    xmlhttp.open("post", obj.url, true);
    // 设置请求头
    // 默认用字符串拼接的形式 application/x-www-form-urlencoded
    // xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // xmlhttp.setRequestHeader('Content-Type', 'multipart/form-data')  // 表单提交  有点效果，但还是不对
    var formData = new FormData();
    for (var key in obj.data) {
      formData.append(key, obj.data[key]);
    }
    xmlhttp.send(formData);
  }

  /**
   * 获取url参数 返回一个对象
   * @returns {{}}
   */
  function getRequestParameters(url) {
    url = url || window.location.href;
    var obj = {};
    var index = url.lastIndexOf('?');
    if (index === -1) return {};
    url = url.substr(index + 1);
    var arr = url.split('&');
    for (var i = 0; i < arr.length; i++) {
      var b = arr[i].indexOf('=');
      // obj[arr[i].substr(0, b).toLocaleLowerCase()] = arr[i].substr(b + 1) // 把地址栏参数名转成小写
      obj[arr[i].substr(0, b)] = arr[i].substr(b + 1);
    }
    return obj;
  }

  var paramList = {
    client_ip: "",
    system: 1,
    brand: "",
    model: "",
    gid: "",
    ifa: "",
    language: "",
    ua: "",
    sdkversion: "",
    im: "",
    ma: "",
    aid: "",
    aq: "",
    os_v: "",
    app_pname: "",
    app_vn: "",
    network: "",
    pub_id: "",
    appid: "",
    unit_id: "",
    game_id: "",
    //测试用的
    session_id: "",
    code: "",
    ad_cat: "",
    r_num: 0,
    offset: 0,
    device_vendor: "",
    api_version: "2.1",
    tk_id: '',
    tk_ts: '',
    rxuid: '',
    req_times: ''
  };
  var protocol = window.location.protocol;
  // 指定必要参数
  paramList.unit_id = 1; // 图片用
  paramList.appid = 1; // 图片用
  paramList.pub_id = '10048'; // 埋点用
  paramList.game_id = '96'; // 埋点用

  /**
   * h5 新埋点
   */
  function apiH5Analytics(name, obj, success) {
    var url = protocol + '//h5-stat.roulax.io/h5_analytics';
    var message = JSON.stringify([{
      k: name,
      v: JSON.stringify(obj)
    }]);
    var data = {
      publisher_id: paramList.pub_id,
      game_id: paramList.game_id,
      appid: paramList.appid,
      unit_id: paramList.unit_id,
      // api_type: radsdk ? 2 : 1,
      api_type: 1,
      message: message,
      // rxuid: rxuid,
      rxuid: '',
      system: paramList.system,
      os_v: paramList.os_v,
      app_pname: paramList.app_pname,
      app_vn: paramList.app_vn,
      direction: paramList.direction,
      brand: paramList.brand,
      model: paramList.model,
      adid: paramList.gid,
      idfa: '',
      mnc: paramList.mnc,
      mcc: paramList.mcc,
      network: paramList.network,
      language: paramList.language,
      timezone: paramList.timezone,
      sdkversion: paramList.sdkversion,
      screen_size: paramList.screen_size,
      ma: paramList.ma,
      mb: paramList.mb,
      mc: paramList.mc0,
      app_bundle_name: paramList.app_bundle_name,
      device_vendor: paramList.device_vendor,
      ext1: '',
      ext2: '',
      ext3: '',
      ext4: '',
      ext5: '',
      ext6: '',
      ext7: '',
      ext8: '',
      ext9: '',
      ext10: ''
    };
    ajaxPost({
      url: url,
      data: data,
      success: success
    });
  }

  (function () {
    window.addEventListener('load', init);
    function init() {
      // getAdImg()
      apiH5Analytics('ad_request', {
        rsession_id: 1,
        req_times: 2
      });
      test('bundle');
    }
    function test(name) {
      // 获取script链接上的参数
      var script = document.querySelectorAll('script');
      var url = '';
      for (var i = 0; i < script.length; i++) {
        if (script[i].src.indexOf(name) > -1) {
          url = script[i].src;
          break;
        }
      }
      console.log(url);
      var obj = getRequestParameters(url);
      console.log(obj);
      var p = document.createElement('p');
      p.innerHTML = obj.t;
      document.body.appendChild(p);
    }
  })();

})();
