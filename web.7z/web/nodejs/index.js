const express = require('express')
let shell = require('shelljs')
const app = express()
const port = 3000

//设置CORS
app.all('*',function (req, res, next) {
  res.header('Access-Control-Allow-Origin','http://localhost:8081'); //当允许携带cookies此处的白名单不能写’*’
  res.header('Access-Control-Allow-Headers','content-type,Content-Length, Authorization,Origin,Accept,X-Requested-With'); //允许的请求头
  res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, PUT'); //允许的请求方法
  res.header('Access-Control-Allow-Credentials',true);  //允许携带cookies
  next();
});
app.get('/build', async (req, res) => {
  console.log('build');
  shell.cd('..')
  shell.exec('npm run build:mobile', () => {
    res.send('ok')
    shell.cd('nodejs')  // 回到上层目录
    process.exit(0)
  })
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})