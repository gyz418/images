// const autoprefixer = require('autoprefixer')
const px2rem = require('postcss-plugin-px2rem')

module.exports = {
    plugins: [
//    autoprefixer(),  vue cli4 postcss 默认开启 autoprefixer
        px2rem({
            rootValue: 75,
            exclude: /[\\/]public[\\/]/,
        })
    ]
};