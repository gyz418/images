const path = require('path')
/*
* 提供给 webStorm 识别路径alias用
* */
const resolve = p => path.resolve(__dirname, p)

module.exports = {
  resolve: {
    alias: {
      'COMPONENTS': resolve('./common/components'),
      'MASKTEMPLATE': resolve('./common/maskTemplate'),
      'TOOLS': resolve('./common/js/tools'),
      'API': resolve('./common/js/api'),
      'MIXINS': resolve('./common/mixins'),
    }
  }
}
