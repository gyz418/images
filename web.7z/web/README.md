1. 整体的本地和线上环境 ok
2. 手机的线上环境 ok
3. 富文本编辑器  https://www.wangeditor.com/v5/for-frame.html#demo
   
- https://github.com/surmon-china/vue-quill-editor 停止维护  7.2k 没有vue3
- https://github.com/ueberdosis/tiptap  16.8k 有vue3
- https://github.com/wangeditor-team/wangEditor 14.6k 
- https://github.com/ckeditor/ckeditor5    6.4k
- https://github.com/froala/wysiwyg-editor 5k


1、怎么跟网址绑定起来？
打包后，就生成了html, 放到线上，指定目录，就绑定了html
1.1  打包啥？
更换入口文件，把main.js 换成其他xx.js

2. 手机750和375的问题
   通过缩放、套DIV解决

3. 打包手机页面内容
   通过命令行，需要nodejs 基本打通

4. 预览问题 页面大了
   预览时，重新修改html根的font-size为37.5px

5. 上线麻烦
   要自己可以直接更新到服务器，不要等别人打包上线。  oss服务器??

6. 富文本编辑器
   `wangEditor`
   6.1 编辑器都是行内样式，缩放不了尺寸，在手机上会变大一倍.
   使用正则替换px为rem
   6.2 编辑器的图片上传？
   6.3 编辑器的表格没边框线，需要自己写默认样式

7. 数据保存

8. 图片上传

9. 截图 
   html2canvas 