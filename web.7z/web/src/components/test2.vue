<template>
  <div>
    <p>this is test2.vue</p>
    <p class="title">{{propObj.title}}</p>
    <img :src="propObj.img" alt="">
    <p>this is test2.vue</p>
    {{num}}
    <input type="text" v-model="phoneNum">
    <div class="btn" @click="ok">submit</div>
  </div>
</template>
<script>
export default {
  props:{
    propObj:{},
    phone:{}
  },
  data(){
    return{
      img:'',
      num:1,
    }
  },
  computed:{
    phoneNum:{
      get(){
        return this.phone
      },
      set(newVal){
        // this.propObj.phoneNum = newVal
        this.$emit('update:phone',newVal)
      }
    }
  },
  mounted() {
    let timeout = setInterval(()=>{
      if(this.num<10){
        this.num++
      }else{
        clearInterval(timeout)
      }
    },1000)
  },
  methods:{
    ok(){
      console.log(this.phoneNum);
    }
  }
}
</script>
<style lang="scss" scoped>
.title{
  text-align: center;
  font-size: 40px;
  line-height: 60px;
}
img{
  width: 600px;
}
input{
  font-size: 30px;
}
.btn{
  width: 100px;
  line-height: 50px;
  color: #00f;
  border:1px solid #f00;
  text-align: center;
  margin:50px auto;
}
</style>