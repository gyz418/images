<template>
  <div>
    <table>
      <tr>
        <td>33</td>
        <td>33</td>
        <td>33</td>
      </tr>
    </table>
    <p class="test1">this is test1.vue</p>
    <p>{{ propObj.title }}</p>
    <img :src="propObj.img" alt="">
    <p>{{ propObj.content }}</p>
    <p>this is content</p>
    <p>this is content</p>
    <div class="btn" @click="test">btn</div>
    <div v-html="propObj.html"></div>
    <div v-html="htmlRem"></div>
    <div class="list">
      <div class="item" v-for="(val,key) in 100" :key="key">{{ val }}</div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    propObj: {}
  },
  data() {
    return {}
  },
  computed: {
    // px 转 rem
    htmlRem: function () {
      let res = this.propObj.html
      if (res) {
        return res.replace(/(\d+)px/g, function (s, t) {
          s = s.replace('px', '');
          var value = parseInt(s)/75;//
          return value + "rem";
        })
      }
      return ''
    }
  },
  methods: {
    test() {
      alert('5666')
    },
  }
}
</script>
<style>
/*编辑器表格需要自己添加样式*/
table {
  border-top: 1px solid #ccc;
  border-left: 1px solid #ccc;
  border-collapse: collapse;
}

table td,
table th {
  border-bottom: 1px solid #ccc;
  border-right: 1px solid #ccc;
  padding: 3px 5px;
}

table th {
  border-bottom: 2px solid #ccc;
  text-align: center;
}

</style>
<style lang="scss" scoped>
.test1 {
  font-size: 90px;
}

img {
  width: 100px;
}
</style>