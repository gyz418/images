<template>
  <div class="main flex">
    <div class="left">
      <p @click="testName">name</p>
      <img style="width:200px" :src="newImg" alt="">
    </div>
    <div class="middle flex-vertical">
      <div class="wrap">
        <div class="mobile" ref="mobile">
          <mobile :list="mobileList"/>
        </div>
      </div>
    </div>
    <div class="right">
      <formLine name="标题" v-if="obj.title">
        <el-input v-model="obj.title" placeholder="请输入内容"></el-input>
      </formLine>
      <formLine name="内容" v-if="obj.content">
        <el-input v-model="obj.content" placeholder="请输入内容"></el-input>
      </formLine>
      <div v-html="obj.html"></div>
      <p style="line-height: 70px;">编辑器：</p>
        <Toolbar
            style="border-bottom: 1px solid #ccc"
            :editor="editor"
            :defaultConfig="toolbarConfig"
            :mode="mode"
        />
        <Editor
            style="height: 200px; overflow-y: hidden;"
            v-model="obj.html"
            :defaultConfig="editorConfig"
            :mode="mode"
            @onCreated="onCreated"
        />

      <div style="height: 100px;"></div>
      <el-input v-model="input" placeholder="请输入内容"></el-input>
      <el-button type="primary" @click="createCanvasImg">截图</el-button>
      <el-button type="primary" @click="preview">预览</el-button>
      <el-button type="primary" @click="createView">生成</el-button>
    </div>
  </div>
</template>
<script>
import mobile from './preview'
import FormLine from "./FormLine";
import {Editor, Toolbar} from '@wangeditor/editor-for-vue'
import '@wangeditor/editor/dist/css/style.css'
import axios from 'axios'
import html2canvas from 'html2canvas'

export default {
  components: {
    FormLine,
    mobile,
    Editor,
    Toolbar,
  },
  data() {
    return {
      input: '',
      mobileList: [],  //
      obj: {},

      // 编辑器
      editor: null,
      html: '',
      toolbarConfig: { },
      editorConfig: { placeholder: '请输入内容...' },
      mode: 'default', // or 'simple'

      newImg:'',
    }
  },
  created() {
    document.documentElement.style.fontSize = 75 + 'px'
  },
  mounted() {
    let obj = {
      title:'haha',
      // img:'https://resource.roulax.io/h5g/p/image/2022-07-14/f53d9032afeb6da6fdd19045d48cead0.png'
      img:'http://placekitten.com/200/300',
      content:'wangEditor 14.6k',
      componentsName:'test1',
      html:'<p>666</p>'
    }
    // 更新数据
    let local = localStorage.getItem('htmlData')
    if(local){
      obj = JSON.parse(local)
    }
    /*obj = {
      componentsName: 'test2',
      title: 'vue-quill-editor 富文本编辑器7.2k',
      img: 'http://placekitten.com/600/300',
      phoneNum:'137'
    }*/
    this.$nextTick(()=>{
      this.obj = obj
    })
    this.mobileList.push({
      app: require(`../components/${obj.componentsName}.vue`).default,  // 组件
      propObj: obj,  // prop
    })
  },
  methods: {
    preview(){
      localStorage.setItem('htmlData',JSON.stringify(this.obj))  // 保存数据
      this.$router.push('/mobile?type=pc')
    },
    createView() {
      console.log(this.obj);
      localStorage.setItem('htmlData',JSON.stringify(this.obj))  // 保存数据
      let url = 'http://localhost:3000/build'
      axios.get(url).then(res=>{
        console.log(res);
      })
      // this.$router.push('/mobile?type=pc')
    },
    createCanvasImg(){
      let pic = this.$refs.mobile
      let $picW = 375
      let $picH = 667
      return new Promise((resolve,reject)=>{
        html2canvas(pic,{
          allowTaint: false, // 跨域
          useCORS: true,
        }).then(canvas=>{
          var canvas2 = document.createElement('canvas');
          var context = canvas2.getContext('2d');
          canvas2.width = $picW;
          canvas2.height = $picH;
          context.drawImage(canvas, 0, 0, $picW, $picH);

          // s.newImg = canvas2.toDataURL('image/jpeg', 0.7).replace('data:image/jpeg;base64,', '');
          this.newImg = canvas2.toDataURL('image/jpeg', 0.7)
          resolve(this.newImg);
        }).catch(err=>{
          console.log('图片生成失败',err);
        })
      })
    },

    // 编辑器
    onCreated(editor) {
      this.editor = Object.seal(editor) // 一定要用 Object.seal() ，否则会报错
    },
    beforeDestroy() {
      const editor = this.editor
      if (editor == null) return
      editor.destroy() // 组件销毁时，及时销毁编辑器
    },
    testName(){
      console.log(123);
    }
  }
}
</script>
<style>
html, body {
  height: 100%;
}
</style>
<style lang="scss" scoped>
.main {
  background: #ccc;
  height: 100%;
}

.left, .right {
  background: #fff;
}

.left {
  width: 300px;
  margin-right: 10px;
}

.middle {
  flex: 1;

  .wrap {
    width: 375px;
    height: 667px;
    position: relative;
  }

  .mobile {
    //top: -50%;
    //left: -50%;
    //position: absolute;
    //transform: scale(0.5);
    transform: translate(-25%,-25%) scale(0.5);
    width: 750px;
    height: 1334px;
    //width:375px;
    //height: 667px;
    background: #fff;
    overflow-y: scroll;
    // 必须设置宽度，只设置颜色不生效
    &::-webkit-scrollbar {
      width: 6px;
    }

    // 滚动条颜色
    &::-webkit-scrollbar-thumb {
      background-color: transparent;
    }
  }
}

.right {
  width: 600px;
  margin-left: 10px;
  padding:10px;
}
</style>
