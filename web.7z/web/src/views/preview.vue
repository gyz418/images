<template>
  <div>
    <div v-if="false" class="a">中华人民共和国中华人民共和国哈哈</div>
    <component
        v-for="(val,key) in list"
        :is="val.app"
        :key="key"
        :propObj="val.propObj"
        :phone.sync="val.propObj.phoneNum"
    ></component>
  </div>
</template>
<script>
export default {
  props: {
    list: {},  // 动态组件
  }
}
</script>
<style lang="scss" scoped>
.a {
  width: 600px;
  height: 400px;
  background: red;
  font-size: 30px;
}
</style>