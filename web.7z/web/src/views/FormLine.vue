<template>
  <div class="title-section flex-center">
    <p class="title">{{name}}</p>
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: 'formLine',
  props:{
    name:{}
  }
}
</script>
<style lang="scss" scoped>
.title-section{
  margin-bottom: 20px;
  .title{
    flex-shrink: 0;
    width:80px;
  }
}
</style>
