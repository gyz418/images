<template>
  <div>
    <p class="phone">手机预览手机预览手机预览手机预览</p>
    <component
        :is="app"
        :propObj="obj"
        :phone.sync="obj.phoneNum"
    ></component>
  </div>
</template>
<script>

export default {
  data(){
    return{
      obj:{},
      syncObj:{},
      app:'',
    }
  },
  created() {
    if(this.$route.query.type==='pc'){
      let w = document.documentElement.clientWidth / 10
      document.documentElement.style.fontSize = w + 'px'
    }
  },
  mounted() {
    let data = localStorage.getItem('htmlData')
    if(!data) return
    let obj = JSON.parse(data)
    this.app = require(`../components/${obj.componentsName}.vue`).default  // 组件
    this.obj =  obj  // prop
  }
}
</script>
<style lang="scss" scoped>
.phone{
  font-size: 40px;
}
</style>