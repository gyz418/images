import Vue from 'vue'
import App from './index.vue'
import '../css/style.scss'

Vue.config.productionTip = false
new Vue({
  render: h => h(App),
}).$mount('#mobile')
