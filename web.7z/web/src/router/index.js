import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/', //  编辑
      component: () => import('../views/index'),
      name: 'index',
      meta: {
        title: '管理后台',
      }
    },
    {
      path: '/mobile', //  手机
      component: () => import('../mobile/index.vue'),
      name: 'preview',
      meta: {
        title: '管理后台',
      }
    },
  ],
  linkActiveClass: 'router-active',
  scrollBehavior(to, from, savedPosition) {
    return { x: 0, y: 0 }
  },
})

router.beforeEach(async (to, from, next) => {
  next()
})

export default router
