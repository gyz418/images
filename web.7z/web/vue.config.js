const {defineConfig} = require('@vue/cli-service')
const VConsolePlugin = require('vconsole-webpack-plugin')
const fs = require('fs')
const path = require('path')
const rawArgv = process.argv.slice(2)
const args = require('minimist')(rawArgv)  // npm run serve turntableConfig test
let isMobile = args.type==='mobile'
console.log('isMobile',isMobile);
const resolve = p => path.resolve(__dirname, p)
module.exports = defineConfig({
  transpileDependencies: true,
  productionSourceMap: false,
  publicPath: './',
  // outputDir: `dist/${args.project}/${args.folder}`,
  outputDir: isMobile? 'distMobile' : 'dist',
  configureWebpack: config => {
    let envType = process.env.NODE_ENV !== 'production'
    let pluginsDev = [
      new VConsolePlugin({
        filter: [],
        enable: envType,
      })
    ]
    config.plugins = [...config.plugins, ...pluginsDev]
    if(isMobile){
      config.entry.app = `./src/mobile/index.js`
    }
    Object.assign(config.resolve, {
      alias: {}
    })
  },
  // 修改标题
  chainWebpack: config => {
    config.plugin('html')
      .tap(item => {
        item[0].title = args.folder;
        item[0].template = './src/index.html'   // 修改html模板文件,默认为src下的index.html
        if(isMobile){
          item[0].template='./src/mobile/index.html'
        }
        return item;
      })
    config.optimization.minimizer('terser').tap(args => {
      args[0].terserOptions.compress.drop_console = true   // 删除console
      return args
    })
  }
})
